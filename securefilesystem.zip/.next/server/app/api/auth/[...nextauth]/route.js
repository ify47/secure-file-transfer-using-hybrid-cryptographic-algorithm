"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/auth/[...nextauth]/route";
exports.ids = ["app/api/auth/[...nextauth]/route"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "../../client/components/action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "../../client/components/request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "../../client/components/static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "node:buffer":
/*!******************************!*\
  !*** external "node:buffer" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("node:buffer");

/***/ }),

/***/ "node:crypto":
/*!******************************!*\
  !*** external "node:crypto" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("node:crypto");

/***/ }),

/***/ "node:events":
/*!******************************!*\
  !*** external "node:events" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("node:events");

/***/ }),

/***/ "node:http":
/*!****************************!*\
  !*** external "node:http" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("node:http");

/***/ }),

/***/ "node:https":
/*!*****************************!*\
  !*** external "node:https" ***!
  \*****************************/
/***/ ((module) => {

module.exports = require("node:https");

/***/ }),

/***/ "node:util":
/*!****************************!*\
  !*** external "node:util" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_Ifeanyi_Documents_siteProjects_securefilesystem_src_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/auth/[...nextauth]/route.ts */ \"(rsc)/./src/app/api/auth/[...nextauth]/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/auth/[...nextauth]/route\",\n        pathname: \"/api/auth/[...nextauth]\",\n        filename: \"route\",\n        bundlePath: \"app/api/auth/[...nextauth]/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\Ifeanyi\\\\Documents\\\\siteProjects\\\\securefilesystem\\\\src\\\\app\\\\api\\\\auth\\\\[...nextauth]\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_Ifeanyi_Documents_siteProjects_securefilesystem_src_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/auth/[...nextauth]/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZhdXRoJTJGJTVCLi4ubmV4dGF1dGglNUQlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRmF1dGglMkYlNUIuLi5uZXh0YXV0aCU1RCUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRmF1dGglMkYlNUIuLi5uZXh0YXV0aCU1RCUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNJZmVhbnlpJTVDRG9jdW1lbnRzJTVDc2l0ZVByb2plY3RzJTVDc2VjdXJlZmlsZXN5c3RlbSU1Q3NyYyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDSWZlYW55aSU1Q0RvY3VtZW50cyU1Q3NpdGVQcm9qZWN0cyU1Q3NlY3VyZWZpbGVzeXN0ZW0maXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNjO0FBQzJEO0FBQ3hJO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsaUVBQWlFO0FBQ3pFO0FBQ0E7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDdUg7O0FBRXZIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2VjdXJlZmlsZXN5c3RlbS8/NDg3NyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxJZmVhbnlpXFxcXERvY3VtZW50c1xcXFxzaXRlUHJvamVjdHNcXFxcc2VjdXJlZmlsZXN5c3RlbVxcXFxzcmNcXFxcYXBwXFxcXGFwaVxcXFxhdXRoXFxcXFsuLi5uZXh0YXV0aF1cXFxccm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2F1dGgvWy4uLm5leHRhdXRoXVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiQzpcXFxcVXNlcnNcXFxcSWZlYW55aVxcXFxEb2N1bWVudHNcXFxcc2l0ZVByb2plY3RzXFxcXHNlY3VyZWZpbGVzeXN0ZW1cXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcYXV0aFxcXFxbLi4ubmV4dGF1dGhdXFxcXHJvdXRlLnRzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuY29uc3Qgb3JpZ2luYWxQYXRobmFtZSA9IFwiL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0vcm91dGVcIjtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgc2VydmVySG9va3MsXG4gICAgICAgIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgb3JpZ2luYWxQYXRobmFtZSwgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./lib/mongodb.ts":
/*!************************!*\
  !*** ./lib/mongodb.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   connectMongoDB: () => (/* binding */ connectMongoDB)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst connectMongoDB = async ()=>{\n    try {\n        await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI);\n    } catch (error) {\n        console.log(\"error\", error);\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvbW9uZ29kYi50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBZ0M7QUFFekIsTUFBTUMsaUJBQWlCO0lBQzFCLElBQUk7UUFDQSxNQUFNRCx1REFBZ0IsQ0FBQ0csUUFBUUMsR0FBRyxDQUFDQyxXQUFXO0lBR2xELEVBQUUsT0FBT0MsT0FBTztRQUNaQyxRQUFRQyxHQUFHLENBQUMsU0FBU0Y7SUFFekI7QUFDSixFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2VjdXJlZmlsZXN5c3RlbS8uL2xpYi9tb25nb2RiLnRzPzA1YmQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xuXG5leHBvcnQgY29uc3QgY29ubmVjdE1vbmdvREIgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgbW9uZ29vc2UuY29ubmVjdChwcm9jZXNzLmVudi5NT05HT0RCX1VSSSBhcyBzdHJpbmcpO1xuICAgICAgICBcbiAgICAgICAgXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ2Vycm9yJywgZXJyb3IpO1xuICAgICAgICBcbiAgICB9XG59Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwiY29ubmVjdE1vbmdvREIiLCJjb25uZWN0IiwicHJvY2VzcyIsImVudiIsIk1PTkdPREJfVVJJIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./lib/mongodb.ts\n");

/***/ }),

/***/ "(rsc)/./models/user.ts":
/*!************************!*\
  !*** ./models/user.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst userSchema = new mongoose__WEBPACK_IMPORTED_MODULE_0__.Schema({\n    name: {\n        type: String,\n        required: true\n    },\n    email: {\n        type: String,\n        required: true\n    },\n    password: {\n        type: String,\n        required: true\n    },\n    passkeydone: {\n        type: Boolean,\n        required: true\n    }\n}, {\n    timestamps: true\n});\nconst User = mongoose__WEBPACK_IMPORTED_MODULE_0__.models.User || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"User\", userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9tb2RlbHMvdXNlci50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBb0Q7QUFFcEQsTUFBTUcsYUFBYSxJQUFJRCw0Q0FBTUEsQ0FBQztJQUMxQkUsTUFBTTtRQUNGQyxNQUFNQztRQUNOQyxVQUFVO0lBQ2Q7SUFDQUMsT0FBTztRQUNISCxNQUFNQztRQUNOQyxVQUFVO0lBQ2Q7SUFDQUUsVUFBVTtRQUNOSixNQUFNQztRQUNOQyxVQUFVO0lBQ2Q7SUFDQUcsYUFBWTtRQUNSTCxNQUFNTTtRQUNOSixVQUFVO0lBQ2Q7QUFFSixHQUFHO0lBQUNLLFlBQVk7QUFBSTtBQUdwQixNQUFNQyxPQUFPWiw0Q0FBTUEsQ0FBQ1ksSUFBSSxJQUFJYixxREFBYyxDQUFDLFFBQVFHO0FBQ25ELGlFQUFlVSxJQUFJQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2VjdXJlZmlsZXN5c3RlbS8uL21vZGVscy91c2VyLnRzPzcwMGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlLCB7IG1vZGVscywgU2NoZW1hIH0gZnJvbSBcIm1vbmdvb3NlXCI7XG5cbmNvbnN0IHVzZXJTY2hlbWEgPSBuZXcgU2NoZW1hKHtcbiAgICBuYW1lOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVxdWlyZWQ6IHRydWVcbiAgICB9LFxuICAgIGVtYWlsOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXG4gICAgfSxcbiAgICBwYXNzd29yZDoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIHJlcXVpcmVkOiB0cnVlLFxuICAgIH0sXG4gICAgcGFzc2tleWRvbmU6e1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICByZXF1aXJlZDogdHJ1ZVxuICAgIH1cbiAgICBcbn0sIHt0aW1lc3RhbXBzOiB0cnVlfVxuKVxuXG5jb25zdCBVc2VyID0gbW9kZWxzLlVzZXIgfHwgbW9uZ29vc2UubW9kZWwoJ1VzZXInLCB1c2VyU2NoZW1hKVxuZXhwb3J0IGRlZmF1bHQgVXNlcjsiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJtb2RlbHMiLCJTY2hlbWEiLCJ1c2VyU2NoZW1hIiwibmFtZSIsInR5cGUiLCJTdHJpbmciLCJyZXF1aXJlZCIsImVtYWlsIiwicGFzc3dvcmQiLCJwYXNza2V5ZG9uZSIsIkJvb2xlYW4iLCJ0aW1lc3RhbXBzIiwiVXNlciIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./models/user.ts\n");

/***/ }),

/***/ "(rsc)/./src/app/api/auth/[...nextauth]/route.ts":
/*!*************************************************!*\
  !*** ./src/app/api/auth/[...nextauth]/route.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ handler),\n/* harmony export */   POST: () => (/* binding */ handler),\n/* harmony export */   authOptions: () => (/* binding */ authOptions)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"(rsc)/./node_modules/next-auth/index.js\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/credentials */ \"(rsc)/./node_modules/next-auth/providers/credentials.js\");\n/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../models/user */ \"(rsc)/./models/user.ts\");\n/* harmony import */ var _lib_mongodb__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../lib/mongodb */ \"(rsc)/./lib/mongodb.ts\");\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bcryptjs */ \"(rsc)/./node_modules/bcryptjs/index.js\");\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _teamhanko_passkeys_next_auth_provider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @teamhanko/passkeys-next-auth-provider */ \"(rsc)/./node_modules/@teamhanko/passkeys-next-auth-provider/index.js\");\n\n\n\n\n\n\nconst authOptions = {\n    providers: [\n        (0,next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__[\"default\"])({\n            name: \"credentials\",\n            credentials: {\n                email: {\n                    label: \"Email\",\n                    type: \"email\",\n                    required: true\n                },\n                password: {\n                    label: \"Password\",\n                    type: \"password\",\n                    required: true\n                }\n            },\n            async authorize (credentials) {\n                if (!credentials) {\n                    return null;\n                }\n                const { email, password } = credentials;\n                try {\n                    await (0,_lib_mongodb__WEBPACK_IMPORTED_MODULE_3__.connectMongoDB)();\n                    const user = await _models_user__WEBPACK_IMPORTED_MODULE_2__[\"default\"].findOne({\n                        email\n                    });\n                    if (!user) {\n                        return null;\n                    }\n                    const passwordsMatch = await bcryptjs__WEBPACK_IMPORTED_MODULE_4___default().compare(password, user.password);\n                    if (!passwordsMatch) {\n                        return null;\n                    }\n                    return user;\n                } catch (error) {\n                    console.log(\"error \", error);\n                }\n            }\n        }),\n        (0,_teamhanko_passkeys_next_auth_provider__WEBPACK_IMPORTED_MODULE_5__.PasskeyProvider)({\n            tenant: (0,_teamhanko_passkeys_next_auth_provider__WEBPACK_IMPORTED_MODULE_5__.tenant)({\n                apiKey: process.env.PASSKEYS_API_KEY,\n                tenantId: \"44159343-07a1-4a1a-96fa-ffacd3256cf0\"\n            }),\n            async authorize ({ userId }) {\n                await (0,_lib_mongodb__WEBPACK_IMPORTED_MODULE_3__.connectMongoDB)();\n                const user = await _models_user__WEBPACK_IMPORTED_MODULE_2__[\"default\"].findOne({\n                    userId: userId\n                });\n                if (!user) return null;\n                // Do more stuff\n                return {\n                    user\n                };\n            }\n        })\n    ],\n    callbacks: {\n        async jwt ({ token, user, trigger, session }) {\n            if (user) {\n                token.name = user.name;\n                token.email = user.email;\n                token.id = user.id;\n                token.passkeydone = user.passkeydone;\n                console.log(\"token\", token);\n            }\n            if (trigger === \"update\" && session?.user?.passkeydone !== undefined) {\n                token.passkeydone = session.user.passkeydone; // Only update passkeydone field\n            }\n            return token;\n        },\n        async session ({ session, token }) {\n            if (token) {\n                session.user.name = token.name;\n                session.user.email = token.email;\n                session.user.id = token.id;\n                session.user.passkeydone = token.passkeydone ?? session.user.passkeydone;\n                console.log(\"sessionn23\", session);\n            }\n            return session;\n        }\n    },\n    // session: {\n    //     strategy: 'jwt',\n    // },\n    secret: process.env.NEXTAUTH_SECRET,\n    pages: {\n        signIn: \"/login\"\n    }\n};\nconst handler = next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions);\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0vcm91dGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBaUM7QUFDaUM7QUFDcEI7QUFDYztBQUM5QjtBQUNtRDtBQThCMUUsTUFBTU8sY0FBbUI7SUFDNUJDLFdBQVc7UUFDUFAsMkVBQW1CQSxDQUFDO1lBQ2hCUSxNQUFNO1lBQ05DLGFBQWE7Z0JBQ1RDLE9BQU87b0JBQUVDLE9BQU87b0JBQVNDLE1BQU07b0JBQVNDLFVBQVU7Z0JBQUs7Z0JBQ3ZEQyxVQUFVO29CQUFFSCxPQUFPO29CQUFZQyxNQUFNO29CQUFZQyxVQUFVO2dCQUFLO1lBQ2xFO1lBRUYsTUFBTUUsV0FBVU4sV0FBVztnQkFDdkIsSUFBSSxDQUFDQSxhQUFhO29CQUN4QixPQUFPO2dCQUNUO2dCQUNPLE1BQU0sRUFBQ0MsS0FBSyxFQUFFSSxRQUFRLEVBQUUsR0FBR0w7Z0JBRTNCLElBQUk7b0JBQ0gsTUFBTVAsNERBQWNBO29CQUNwQixNQUFNYyxPQUFPLE1BQU1mLG9EQUFJQSxDQUFDZ0IsT0FBTyxDQUFDO3dCQUFDUDtvQkFBSztvQkFFdEMsSUFBSSxDQUFDTSxNQUFNO3dCQUNQLE9BQU87b0JBQ1g7b0JBSUQsTUFBTUUsaUJBQWlCLE1BQU1mLHVEQUFjLENBQUNXLFVBQVVFLEtBQUtGLFFBQVE7b0JBRW5FLElBQUksQ0FBQ0ksZ0JBQWdCO3dCQUNwQixPQUFPO29CQUNSO29CQUdBLE9BQU9GO2dCQUNQLEVBQUUsT0FBT0ksT0FBTztvQkFDZkMsUUFBUUMsR0FBRyxDQUFDLFVBQVNGO2dCQUV0QjtZQUNIO1FBQ0o7UUFDQWhCLHVGQUFlQSxDQUFDO1lBQ1pDLFFBQVFBLDhFQUFNQSxDQUFDO2dCQUNia0IsUUFBUUMsUUFBUUMsR0FBRyxDQUFDQyxnQkFBZ0I7Z0JBQ3BDQyxVQUFVSCxzQ0FBMEM7WUFDdEQ7WUFDQSxNQUFNVCxXQUFVLEVBQUVjLE1BQU0sRUFBRTtnQkFDdEIsTUFBTTNCLDREQUFjQTtnQkFFcEIsTUFBTWMsT0FBTyxNQUFNZixvREFBSUEsQ0FBQ2dCLE9BQU8sQ0FBQztvQkFBQ1ksUUFBUUE7Z0JBQU07Z0JBRS9DLElBQUksQ0FBQ2IsTUFBTSxPQUFPO2dCQUVwQixnQkFBZ0I7Z0JBRWhCLE9BQU87b0JBQ0xBO2dCQUNGO1lBQ0Y7UUFDRjtLQUNMO0lBQ0RjLFdBQVU7UUFDTixNQUFNQyxLQUFJLEVBQUNDLEtBQUssRUFBQ2hCLElBQUksRUFBRWlCLE9BQU8sRUFBRUMsT0FBTyxFQUFtRTtZQUN0RyxJQUFHbEIsTUFBTTtnQkFDTGdCLE1BQU14QixJQUFJLEdBQUdRLEtBQUtSLElBQUk7Z0JBQ3RCd0IsTUFBTXRCLEtBQUssR0FBR00sS0FBS04sS0FBSztnQkFDeEJzQixNQUFNRyxFQUFFLEdBQUduQixLQUFLbUIsRUFBRTtnQkFDbEJILE1BQU1JLFdBQVcsR0FBR3BCLEtBQUtvQixXQUFXO2dCQUNwQ2YsUUFBUUMsR0FBRyxDQUFDLFNBQVNVO1lBRXpCO1lBQ0EsSUFBSUMsWUFBWSxZQUFZQyxTQUFTbEIsTUFBTW9CLGdCQUFnQkMsV0FBVztnQkFDcEVMLE1BQU1JLFdBQVcsR0FBR0YsUUFBUWxCLElBQUksQ0FBQ29CLFdBQVcsRUFBRSxnQ0FBZ0M7WUFDaEY7WUFDQSxPQUFPSjtRQUNYO1FBQ0EsTUFBTUUsU0FBUSxFQUFDQSxPQUFPLEVBQUVGLEtBQUssRUFBaUM7WUFDMUQsSUFBSUEsT0FBTztnQkFDUEUsUUFBUWxCLElBQUksQ0FBQ1IsSUFBSSxHQUFHd0IsTUFBTXhCLElBQUk7Z0JBQzlCMEIsUUFBUWxCLElBQUksQ0FBQ04sS0FBSyxHQUFHc0IsTUFBTXRCLEtBQUs7Z0JBQ2hDd0IsUUFBUWxCLElBQUksQ0FBQ21CLEVBQUUsR0FBR0gsTUFBTUcsRUFBRTtnQkFDMUJELFFBQVFsQixJQUFJLENBQUNvQixXQUFXLEdBQUdKLE1BQU1JLFdBQVcsSUFBSUYsUUFBUWxCLElBQUksQ0FBQ29CLFdBQVc7Z0JBRXhFZixRQUFRQyxHQUFHLENBQUMsY0FBY1k7WUFFOUI7WUFFQSxPQUFPQTtRQUNYO0lBQ0o7SUFFQSxhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLEtBQUs7SUFDTEksUUFBUWQsUUFBUUMsR0FBRyxDQUFDYyxlQUFlO0lBQ25DQyxPQUFPO1FBQ0hDLFFBQVE7SUFDWjtBQUNKLEVBQUM7QUFFRCxNQUFNQyxVQUFVM0MsZ0RBQVFBLENBQUNPO0FBRWUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zZWN1cmVmaWxlc3lzdGVtLy4vc3JjL2FwcC9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlLnRzPzAwOTgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE5leHRBdXRoIGZyb20gXCJuZXh0LWF1dGhcIjtcbmltcG9ydCBDcmVkZW50aWFsc1Byb3ZpZGVyIGZyb20gXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2NyZWRlbnRpYWxzXCI7XG5pbXBvcnQgVXNlciBmcm9tIFwiLi4vLi4vLi4vLi4vLi4vbW9kZWxzL3VzZXJcIjtcbmltcG9ydCB7IGNvbm5lY3RNb25nb0RCIH0gZnJvbSBcIi4uLy4uLy4uLy4uLy4uL2xpYi9tb25nb2RiXCI7XG5pbXBvcnQgYmNyeXB0IGZyb20gJ2JjcnlwdGpzJztcbmltcG9ydCB7IFBhc3NrZXlQcm92aWRlciwgdGVuYW50IH0gZnJvbSBcIkB0ZWFtaGFua28vcGFzc2tleXMtbmV4dC1hdXRoLXByb3ZpZGVyXCI7XG5cbnR5cGUgVXNlclR5cGUgPSB7XG4gICAgcGFzc2tleWRvbmU6IGFueTtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgZW1haWw6IHN0cmluZztcbiAgICBwYXNzd29yZDogc3RyaW5nO1xuICAgIGlkOiBzdHJpbmc7XG4gIH07XG5cbnR5cGUgVG9rZW4gPSB7XG4gICAgcGFzc2tleWRvbmU6IGJvb2xlYW47XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIGVtYWlsOiBzdHJpbmc7XG4gICAgaWQ6IHN0cmluZztcbiAgfVxuXG4gIGRlY2xhcmUgbW9kdWxlIFwibmV4dC1hdXRoXCIge1xuICAgIGludGVyZmFjZSBTZXNzaW9uIHtcbiAgICAgIHVzZXI6XG4gICAgICAgIHwge1xuICAgICAgICAgICAgbmFtZT86IHN0cmluZyB8IG51bGw7XG4gICAgICAgICAgICBlbWFpbD86IHN0cmluZyB8IG51bGw7XG4gICAgICAgICAgICBpZD86IHN0cmluZyB8IG51bGw7XG4gICAgICAgICAgICBwYXNza2V5ZG9uZT86IGJvb2xlYW5cbiAgICAgICAgICB9XG4gICAgICAgIHwgdW5kZWZpbmVkO1xuICAgIH1cbiAgfVxuXG5leHBvcnQgY29uc3QgYXV0aE9wdGlvbnM6IGFueSA9IHtcbiAgICBwcm92aWRlcnM6IFtcbiAgICAgICAgQ3JlZGVudGlhbHNQcm92aWRlcih7XG4gICAgICAgICAgICBuYW1lOiAnY3JlZGVudGlhbHMnLFxuICAgICAgICAgICAgY3JlZGVudGlhbHM6IHtcbiAgICAgICAgICAgICAgICBlbWFpbDogeyBsYWJlbDogXCJFbWFpbFwiLCB0eXBlOiBcImVtYWlsXCIsIHJlcXVpcmVkOiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHsgbGFiZWw6IFwiUGFzc3dvcmRcIiwgdHlwZTogXCJwYXNzd29yZFwiLCByZXF1aXJlZDogdHJ1ZSB9LFxuICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICBhc3luYyBhdXRob3JpemUoY3JlZGVudGlhbHMpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWNyZWRlbnRpYWxzKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgICAgICAgIGNvbnN0IHtlbWFpbCwgcGFzc3dvcmQgfSA9IGNyZWRlbnRpYWxzO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBjb25uZWN0TW9uZ29EQigpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBVc2VyLmZpbmRPbmUoe2VtYWlsfSlcblxuICAgICAgICAgICAgICAgIGlmICghdXNlcikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgICAgICAgICAgIH1cblxuXG5cbiAgICAgICAgICAgICAgIGNvbnN0IHBhc3N3b3Jkc01hdGNoID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUocGFzc3dvcmQsIHVzZXIucGFzc3dvcmQpXG5cbiAgICAgICAgICAgICAgIGlmICghcGFzc3dvcmRzTWF0Y2gpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgXG5cbiAgICAgICAgICAgICAgIHJldHVybiB1c2VyXG4gICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3IgXCIsZXJyb3IpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KSxcbiAgICAgICAgUGFzc2tleVByb3ZpZGVyKHtcbiAgICAgICAgICAgIHRlbmFudDogdGVuYW50KHtcbiAgICAgICAgICAgICAgYXBpS2V5OiBwcm9jZXNzLmVudi5QQVNTS0VZU19BUElfS0VZIGFzIHN0cmluZyxcbiAgICAgICAgICAgICAgdGVuYW50SWQ6IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1BBU1NLRVlTX1RFTkFOVF9JRCBhcyBzdHJpbmcsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGFzeW5jIGF1dGhvcml6ZSh7IHVzZXJJZCB9KSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgY29ubmVjdE1vbmdvREIoKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgVXNlci5maW5kT25lKHt1c2VySWQ6IHVzZXJJZH0pO1xuXG4gICAgICAgICAgICAgICAgaWYgKCF1c2VyKSByZXR1cm4gbnVsbDtcbiAgICAgIFxuICAgICAgICAgICAgICAvLyBEbyBtb3JlIHN0dWZmXG4gICAgICBcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB1c2VyXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgIF0sXG4gICAgY2FsbGJhY2tzOntcbiAgICAgICAgYXN5bmMgand0KHt0b2tlbix1c2VyLCB0cmlnZ2VyLCBzZXNzaW9ufTogeyB0b2tlbjogVG9rZW47IHVzZXI/OiBVc2VyVHlwZTsgdHJpZ2dlcjogc3RyaW5nOyBzZXNzaW9uOiBhbnkgfSkge1xuICAgICAgICAgICAgaWYodXNlcikge1xuICAgICAgICAgICAgICAgIHRva2VuLm5hbWUgPSB1c2VyLm5hbWU7XG4gICAgICAgICAgICAgICAgdG9rZW4uZW1haWwgPSB1c2VyLmVtYWlsO1xuICAgICAgICAgICAgICAgIHRva2VuLmlkID0gdXNlci5pZFxuICAgICAgICAgICAgICAgIHRva2VuLnBhc3NrZXlkb25lID0gdXNlci5wYXNza2V5ZG9uZVxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidG9rZW5cIiwgdG9rZW4pO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRyaWdnZXIgPT09ICd1cGRhdGUnICYmIHNlc3Npb24/LnVzZXI/LnBhc3NrZXlkb25lICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgdG9rZW4ucGFzc2tleWRvbmUgPSBzZXNzaW9uLnVzZXIucGFzc2tleWRvbmU7IC8vIE9ubHkgdXBkYXRlIHBhc3NrZXlkb25lIGZpZWxkXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdG9rZW5cbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgc2Vzc2lvbih7c2Vzc2lvbiwgdG9rZW59OiB7IHNlc3Npb246IGFueTsgdG9rZW46IFRva2VuIH0pIHtcbiAgICAgICAgICAgIGlmICh0b2tlbikge1xuICAgICAgICAgICAgICAgIHNlc3Npb24udXNlci5uYW1lID0gdG9rZW4ubmFtZVxuICAgICAgICAgICAgICAgIHNlc3Npb24udXNlci5lbWFpbCA9IHRva2VuLmVtYWlsXG4gICAgICAgICAgICAgICAgc2Vzc2lvbi51c2VyLmlkID0gdG9rZW4uaWRcbiAgICAgICAgICAgICAgICBzZXNzaW9uLnVzZXIucGFzc2tleWRvbmUgPSB0b2tlbi5wYXNza2V5ZG9uZSA/PyBzZXNzaW9uLnVzZXIucGFzc2tleWRvbmU7XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNlc3Npb25uMjNcIiwgc2Vzc2lvbik7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBzZXNzaW9uXG4gICAgICAgIH1cbiAgICB9XG4gICAgLFxuICAgIC8vIHNlc3Npb246IHtcbiAgICAvLyAgICAgc3RyYXRlZ3k6ICdqd3QnLFxuICAgIC8vIH0sXG4gICAgc2VjcmV0OiBwcm9jZXNzLmVudi5ORVhUQVVUSF9TRUNSRVQsXG4gICAgcGFnZXM6IHtcbiAgICAgICAgc2lnbkluOiAnL2xvZ2luJ1xuICAgIH1cbn1cblxuY29uc3QgaGFuZGxlciA9IE5leHRBdXRoKGF1dGhPcHRpb25zKVxuXG5leHBvcnQge2hhbmRsZXIgYXMgR0VULCBoYW5kbGVyIGFzIFBPU1R9Il0sIm5hbWVzIjpbIk5leHRBdXRoIiwiQ3JlZGVudGlhbHNQcm92aWRlciIsIlVzZXIiLCJjb25uZWN0TW9uZ29EQiIsImJjcnlwdCIsIlBhc3NrZXlQcm92aWRlciIsInRlbmFudCIsImF1dGhPcHRpb25zIiwicHJvdmlkZXJzIiwibmFtZSIsImNyZWRlbnRpYWxzIiwiZW1haWwiLCJsYWJlbCIsInR5cGUiLCJyZXF1aXJlZCIsInBhc3N3b3JkIiwiYXV0aG9yaXplIiwidXNlciIsImZpbmRPbmUiLCJwYXNzd29yZHNNYXRjaCIsImNvbXBhcmUiLCJlcnJvciIsImNvbnNvbGUiLCJsb2ciLCJhcGlLZXkiLCJwcm9jZXNzIiwiZW52IiwiUEFTU0tFWVNfQVBJX0tFWSIsInRlbmFudElkIiwiTkVYVF9QVUJMSUNfUEFTU0tFWVNfVEVOQU5UX0lEIiwidXNlcklkIiwiY2FsbGJhY2tzIiwiand0IiwidG9rZW4iLCJ0cmlnZ2VyIiwic2Vzc2lvbiIsImlkIiwicGFzc2tleWRvbmUiLCJ1bmRlZmluZWQiLCJzZWNyZXQiLCJORVhUQVVUSF9TRUNSRVQiLCJwYWdlcyIsInNpZ25JbiIsImhhbmRsZXIiLCJHRVQiLCJQT1NUIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/auth/[...nextauth]/route.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/next-auth","vendor-chunks/@babel","vendor-chunks/openid-client","vendor-chunks/jose","vendor-chunks/bcryptjs","vendor-chunks/oauth","vendor-chunks/preact","vendor-chunks/yallist","vendor-chunks/@teamhanko","vendor-chunks/preact-render-to-string","vendor-chunks/openapi-fetch","vendor-chunks/cookie","vendor-chunks/oidc-token-hash","vendor-chunks/@panva"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CIfeanyi%5CDocuments%5CsiteProjects%5Csecurefilesystem&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();