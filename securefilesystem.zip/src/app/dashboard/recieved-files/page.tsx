import DashboardNav from "@/components/dashboadNav";
import RecievedOne from "./components/recievedOne";

export default function RecievedFiles() {
  return (
    <>
      <RecievedOne />
    </>
  );
}
