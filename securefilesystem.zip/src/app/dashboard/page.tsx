import DashboardNav from "@/components/dashboadNav";
import UserInfo from "@/components/userInfo";

export default function Dashboard() {
  return (
    <>
      <UserInfo />
    </>
  );
}
