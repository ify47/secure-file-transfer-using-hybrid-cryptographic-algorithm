import React from "react";
import SettingsOne from "./components/settingsOne";

export default function Settings() {
  return (
    <main>
      <SettingsOne />
    </main>
  );
}
