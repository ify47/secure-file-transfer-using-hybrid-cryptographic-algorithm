"use server"
import { Storage } from "@google-cloud/storage";
import { decodeShortKey, decryptContent, decryptWithPrivateKey, encryptContent, encryptWithPublicKey, generateKey, generateShortKey } from './encryptionAes';
import path from 'path';
import crypto from 'crypto';

const projectId = process.env.PROJECT_ID;
const keyFilename = process.env.KEYFILENAME;
const bucketName = process.env.BUCKET_NAME;

// RSA Public and Private Key (For simplicity, assume you've already generated these)
const publicKey = process.env.PUBLIC_KEY as string;
const privateKey = process.env.PRIVATE_KEY as string;

export const UploadFile = async (form: FormData, userEmail: string, senderName: string) => {
    try {
        const file = form.get('file') as File;
        if (!file) throw new Error('No file provided');
        if (file.size < 1) throw new Error('File is empty');

        const buffer = await file.arrayBuffer();
        const uint8Array = new Uint8Array(buffer);

        // Generate an AES encryption key for the file content
        const aesKey = generateKey();
        // Measure the AES encryption time
        const startEncrypt = performance.now();
        const encryptedContent = encryptContent(uint8Array, aesKey);
        const endEncrypt = performance.now();
        const encryptionTime = endEncrypt - startEncrypt;
        console.log(`AES Encryption Time: ${encryptionTime} ms`);

        // Encrypt the AES key using RSA public key encryption
        const rsaEncryptedKey = encryptWithPublicKey(aesKey, publicKey);

        // Split the RSA-encrypted key into two parts
        const firstPartKey = rsaEncryptedKey.slice(0, 16); // First 16 characters to send to the user
        const remainingKey = rsaEncryptedKey.slice(16); // Remaining part to be encrypted

        // Encrypt the remaining part using AES-256-CBC
        const encryptedRemainingKey = generateShortKey(remainingKey);

        // Measure AES decryption time (optional)
        const startDecrypt = performance.now();
        decryptContent(encryptedContent, aesKey);
        const endDecrypt = performance.now();
        const decryptionTime = endDecrypt - startDecrypt;
        console.log(`AES Decryption Time: ${decryptionTime} ms`);

       

        const storage = new Storage({ projectId, keyFilename });
        const bucket = storage.bucket(bucketName as string);

        // Save the encrypted content to the bucket with a .enc extension
        const encryptedFileName = `${file.name}.enc`;
        await bucket.file(encryptedFileName).save(Buffer.from(encryptedContent, 'utf8'));

        const fileType = file.type;  // MIME type
        const fileSize = file.size;  // File size in bytes
        const uploadTime = new Date().toISOString();
        // Store the original file name, user's email, and encrypted remaining key in metadata
        const metadata = {
            metadata: {
                originalName: file.name,
                userEmail: userEmail,  // Recipient's email
                senderName: senderName,  // Sender's name
                fileType: fileType,  // MIME type of the file
                fileSize: fileSize,  // Size in bytes
                uploadTime: uploadTime,  // Time of upload
                encryptedRemainingKey: encryptedRemainingKey, // Store encrypted remaining part of the key
            },
        };
        await bucket.file(encryptedFileName).setMetadata(metadata);

        // Return the first 16 digits of the RSA-encrypted AES key to the user
        return { success: true, key: firstPartKey, encryptionTime, decryptionTime };
    } catch (error) {
        if (error instanceof Error) {
            console.error(error.message);
            return { success: false, error: error.message };
        } else {
            console.error("An unknown error occurred");
            return { success: false, error: "Unknown error" };
        }
    }
};




export const FetchFiles = async (userEmail: string) => {
    try {
        const storage = new Storage({ projectId, keyFilename });
        const bucket = storage.bucket(bucketName as string);
        const [files] = await bucket.getFiles();

        // Fetch the original names from the metadata and filter by the user's email
        const fileList = await Promise.all(files.map(async (file) => {
            const [metadata] = await file.getMetadata();

            // Check if the file belongs to the user by comparing the userEmail stored in metadata
            if (metadata.metadata?.userEmail === userEmail) {
                return {
                    originalName: metadata.metadata?.originalName as string || file.name.replace('.enc', ''),
                    encryptedName: file.name,
                    senderName: metadata.metadata?.senderName as string || 'Unknown',  // Get the sender's name
                    fileType: metadata.metadata?.fileType as string || 'Unknown',  // Get file MIME type
                    fileSize: metadata.metadata?.fileSize as number || 0,  // Get file size in bytes
                    uploadTime: metadata.metadata?.uploadTime as string || 'Unknown',  // Get upload time
                };
            }
            return null;
        }));

        // Filter out any null results (files not meant for the user)
        const userFiles = fileList.filter(file => file !== null);

        return { success: true, files: userFiles };
    } catch (error) {
        if (error instanceof Error) {
            console.error(error.message);
            return { success: false, error: error.message };
        } else {
            console.error("An unknown error occurred");
            return { success: false, error: "Unknown error" };
        }
    }
};


export const DownloadFile = async (encryptedFileName: string, firstPartKey: string) => {
    try {
        const storage = new Storage({ projectId, keyFilename });
        const bucket = storage.bucket(bucketName as string);
        const file = bucket.file(encryptedFileName);
        const exists = await file.exists();

        if (!exists[0]) {
            throw new Error("File does not exist");
        }

        const [encryptedContent] = await file.download();

        // Retrieve the encrypted remaining part of the RSA-encrypted AES key from metadata
        const [metadata] = await file.getMetadata();
        const encryptedRemainingKey = metadata.metadata?.encryptedRemainingKey;

        if (!encryptedRemainingKey) {
            throw new Error("Missing encryption metadata");
        }

        // Decrypt the remaining part using AES-256-CBC
        const remainingPartKey = decodeShortKey(encryptedRemainingKey as string);
        

        // Combine the two parts to reconstruct the full RSA-encrypted AES key
        const fullEncryptedKey = firstPartKey + remainingPartKey;

        // Decrypt the RSA-encrypted AES key using the RSA private key
        let aesKey;
        try {
            aesKey = decryptWithPrivateKey(fullEncryptedKey, privateKey);
        } catch (error) {
            throw new Error("Invalid decryption key");
        }

        // Decrypt the file content using the AES key
        let decryptedContent;
        try {
            decryptedContent = decryptContent(encryptedContent.toString('utf8'), aesKey);
        } catch (error) {
            throw new Error("Failed to decrypt file");
        }

        // Retrieve the original file name from metadata
        const originalFileName = metadata.metadata?.originalName || encryptedFileName.replace('.enc', '');

        // Convert the Uint8Array to Base64 string
        const base64Content = Buffer.from(decryptedContent).toString('base64');

        return { content: base64Content, originalFileName };
    } catch (error) {
        if (error instanceof Error) {
            console.error("Error during file download:", error.message);
            throw new Error("Unable to retrieve or decrypt file. Please check the key and try again.");
        } else {
            console.error("An unknown error occurred");
            return { success: false, error: "Unknown error" };
        }
    }
};



