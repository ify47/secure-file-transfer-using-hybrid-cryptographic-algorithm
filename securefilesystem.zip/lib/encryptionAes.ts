import CryptoJS from 'crypto-js';
import crypto from 'crypto';

// Encrypt content using AES
export function encryptContent(content: Uint8Array, key: string): string {
    const magicString = "MAGICSTRING";  // This string will be used to validate the decryption
    const magicStringBytes = new TextEncoder().encode(magicString);
    const combinedContent = new Uint8Array(magicStringBytes.length + content.length);
    combinedContent.set(magicStringBytes);
    combinedContent.set(content, magicStringBytes.length);

    // Convert combined content to WordArray (needed for AES encryption)
    const wordArray = CryptoJS.lib.WordArray.create(combinedContent);

    // Encrypt the wordArray using AES
    const encrypted = CryptoJS.AES.encrypt(wordArray, key);
    return encrypted.toString();  // Return encrypted content as string
}

// Decrypt content using AES
export function decryptContent(encryptedContent: string, key: string): Uint8Array {
    // Decrypt the encrypted content using AES
    const decrypted = CryptoJS.AES.decrypt(encryptedContent, key);
    
    // Convert decrypted data into a WordArray
    const wordArray = decrypted.toString(CryptoJS.enc.Base64);
    const bytes = CryptoJS.enc.Base64.parse(wordArray).words;

    // Convert WordArray back into Uint8Array
    const decryptedBytes = new Uint8Array(bytes.length * 4).map((_, i) => (bytes[i >>> 2] >>> ((3 - (i % 4)) * 8)) & 0xff);

    return decryptedBytes;
}

// Generate AES key (128-bit)
export function generateKey(): string {
    return CryptoJS.lib.WordArray.random(32).toString(CryptoJS.enc.Hex);  // Generate 128-bit key
}



// Generate RSA key pair (you can use this to generate your keys)
export function generateKeyPair() {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicKeyEncoding: {
            type: 'spki',
            format: 'pem',
        },
        privateKeyEncoding: {
            type: 'pkcs8',
            format: 'pem',
        },
    });
    return { publicKey, privateKey };
}

// Encrypt data with the RSA public key
export function encryptWithPublicKey(data: string, publicKey: string): string {
    try {
        const buffer = Buffer.from(data);
        const encrypted = crypto.publicEncrypt(publicKey, buffer);
        return encrypted.toString('base64');
    } catch (error) {
        console.error("RSA Encryption Error:", error);
        throw new Error("Failed to encrypt data with RSA key.");
    }
}

// Decrypt data with the RSA private key
export function decryptWithPrivateKey(encryptedData: string, privateKey: string): string {
    try {
        const buffer = Buffer.from(encryptedData, 'base64');
        const decrypted = crypto.privateDecrypt(privateKey, buffer);
        return decrypted.toString();
    } catch (error) {
        console.error("RSA Decryption Error:", error);
        throw new Error("Failed to decrypt data with RSA key.");
    }
}

const AES_KEY = Buffer.from(process.env.AESKEY as string, 'base64');
// Generate a 128-bit IV (16 bytes) for AES
const AES_IV = Buffer.from(process.env.AESIV as string, 'base64');


export function generateShortKey(rsaEncryptedKey: string) {
    const cipher = crypto.createCipheriv('aes-256-cbc', AES_KEY, AES_IV);
    let encrypted = cipher.update(rsaEncryptedKey, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}


export function decodeShortKey(shortKey: string) {
    const decipher = crypto.createDecipheriv('aes-256-cbc', AES_KEY, AES_IV);
    let decrypted = decipher.update(shortKey, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}